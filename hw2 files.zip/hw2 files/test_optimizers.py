"""Quick checks on the optimizers (Part A): run this before the 30-seed experiment.

    python test_optimizers.py

Step 1: solve sphere (known answer 0) at the real budget.
Step 2: same seed twice must give identical results.
"""
import numpy as np

from benchmarks import sphere
from protocol import BUDGET, run_pso, run_de, quiet

ALGOS = [("PSO", run_pso), ("DE", run_de)]

if __name__ == "__main__":
    print("Step 1: sphere sanity check (seed 0)")
    for name, algo in ALGOS:
        fx, g, n_evals = quiet(algo, sphere, 0)
        print(f"{name}: best={fx:.6g}  (should be near 0)   evaluations={n_evals}  (should be {BUDGET})")
        assert n_evals == BUDGET

    print("\nStep 2: reproducibility (seed 7, run twice)")
    for name, algo in ALGOS:
        fa, ga, _ = quiet(algo, sphere, 7)
        fb, gb, _ = quiet(algo, sphere, 7)
        assert fa == fb and np.array_equal(ga, gb)
        print(f"{name}: identical results OK")
