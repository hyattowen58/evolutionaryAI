import numpy as np


# NP = population size
# D  = number of dimensions
# lb = lower bound
# ub = upper bound
# G  = number of generations
# F  = differential weight
# CR = crossover rate
# func = function to minimize (takes (NP, D) array, returns (NP,) array)
# seed = RNG seed; same seed -> identical results
def de(NP, D, lb, ub, G, F, CR, func, seed):
    #all randomness goes through this generator, which is why same seed repeats exactly
    rng = np.random.default_rng(seed)

    #initial population, uniform in [lb, ub]
    x = lb + rng.random((NP, D)) * (ub - lb)
    fx = func(x)
    n_evals = NP

    #best member of starting position
    index = np.argmin(fx)
    gbest = x[index].copy()	#copied so it doesn't change when x changes later
    fx_gbest = fx[index]

    for t in range(G):
        #every trial is built from x as it stood
        #at the start of the generation
        trial = np.empty_like(x)

        for i in range(NP):
            # r1, r2, r3 distinct from each other and from i
            candidates = [j for j in range(NP) if j != i]
            r1, r2, r3 = rng.choice(candidates, size=3, replace=False)

            #mutation
            v = x[r1] + F * (x[r2] - x[r3])

            #binomial crossover; j_rand is forced from the donor, so u != x[i]
            j_rand = rng.integers(D)
            cross = rng.random(D) < CR
            cross[j_rand] = True
            u = np.where(cross, v, x[i])

            trial[i] = np.clip(u, lb, ub)

        fx_trial = func(trial) 	#score all trials in one call
        n_evals += NP

        #one-to-one selection: each trial competes only with its own target
        better = fx_trial < fx
        x[better] = trial[better]
        fx[better] = fx_trial[better]

	#update the overall best if something in the population beat it
        index = np.argmin(fx)
        if fx[index] < fx_gbest:
            gbest = x[index].copy()
            fx_gbest = fx[index]

        print(fx_gbest)	#best so far each generation
    #budget check
    assert n_evals == NP * (1 + G), f"expected {NP*(1+G)} evaluations, spent {n_evals}"
    return fx_gbest, gbest, n_evals
