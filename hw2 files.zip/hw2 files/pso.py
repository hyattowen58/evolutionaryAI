import numpy as np


# N = Number of particles
# n = number of dimensions
# lb = lower bound
# ub = upper bound
# T =  Total number of iterations
# W = Inertia
# C1 =  Cognitive coefficient
# C2 = Social coefficient
# func = function to minimize (takes (N, n) array, returns (N,) array)
# seed = RNG seed; same seed -> identical results
def pso(N, n, lb, ub, T, W, C1, C2, func, seed):
    rng = np.random.default_rng(seed)

    #initialise positions uniformly in [lb, ub], velocities at zero
    x = lb + rng.random((N, n)) * (ub - lb)
    v = np.zeros((N, n))
    fx = func(x)
    n_evals = N

    #personal bests
    pbest = x.copy()
    fx_pbest = fx.copy()

    #global best (.copy() so it doesn't alias a row of pbest, which changes later)
    index = np.argmin(fx_pbest)
    gbest = pbest[index].copy()
    fx_gbest = fx_pbest[index]

    for t in range(T):
        # Velocity update: inertia + cognitive pull + social pull
        r1 = rng.random((N, n))
        r2 = rng.random((N, n))
        v = W * v + C1 * r1 * (pbest - x) + C2 * r2 * (gbest - x)

        #position update, kept inside the search bounds
        x = np.clip(x + v, lb, ub)
        fx = func(x)
        n_evals += N

        #update personal bests
        improved = fx < fx_pbest
        pbest[improved] = x[improved]
        fx_pbest[improved] = fx[improved]

        #update global best
        index = np.argmin(fx_pbest)
        if fx_pbest[index] < fx_gbest:
            gbest = pbest[index].copy()
            fx_gbest = fx_pbest[index]

        print(fx_gbest)

    assert n_evals == N * (1 + T), f"expected {N*(1+T)} evaluations, spent {n_evals}"
    return fx_gbest, gbest, n_evals
