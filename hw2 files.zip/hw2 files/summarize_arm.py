"""Part G summary: build the results table from the raw run files.

    python summarize_arm.py                 # reads arm_runs_PSO.csv and arm_runs_DE.csv
    python summarize_arm.py --target 8

run_arm.py calls this automatically when one invocation ran both methods. Run it
by hand after running PSO and DE in two separate windows:

    python run_arm.py --gens 40 --runs 10 --methods PSO
    python run_arm.py --gens 40 --runs 10 --methods DE
    python summarize_arm.py

Reads:   arm_runs_PSO.csv, arm_runs_DE.csv, arm_config_*.json
Writes:  arm_summary.csv, arm_best_angles_pso.csv, arm_best_angles_de.csv,
         arm_best_angles.csv (the overall winner, which arm-visualize.py reads)
"""
import argparse
import csv
import glob
import json
import os
import sys

import numpy as np

import arm


def load_runs(method):
    path = f"arm_runs_{method}.csv"
    if not os.path.exists(path):
        sys.exit(f"Missing {path}. Run: python run_arm.py --gens <G> --methods {method}")
    with open(path, newline="") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        sys.exit(f"{path} has no runs in it.")
    return [(int(r["seed"]), float(r["distance_m"]),
             [float(r[f"angle{j + 1}"]) for j in range(arm.n)]) for r in rows]


def find_budget():
    budgets = set()
    for path in glob.glob("arm_config_*.json"):
        with open(path) as fh:
            budgets.add(json.load(fh)["budget_evaluations"])
    if not budgets:
        return None
    if len(budgets) > 1:
        sys.exit(f"The config files disagree about the budget: {sorted(budgets)}. "
                 "Both methods must use the same budget.")
    return budgets.pop()


def summarize(target=8.0):
    runs = {m: load_runs(m) for m in ("PSO", "DE")}

    seeds = {m: sorted(r[0] for r in runs[m]) for m in runs}
    if seeds["PSO"] != seeds["DE"]:
        sys.exit(f"PSO and DE were not run on the same seeds.\n  PSO: {seeds['PSO']}\n  DE:  {seeds['DE']}")
    budget = find_budget()

    print("\nLanding distance in meters -- LARGER IS BETTER (reverse of Part 1)")
    print("method | runs | budget | best | worst | mean | std | runs >= %g m" % target)
    best_vec, summary_rows = {}, []
    for m in ("PSO", "DE"):
        d = np.array([r[1] for r in runs[m]])
        k = int(np.argmax(d))
        best_vec[m] = (d[k], runs[m][k][2], runs[m][k][0])
        n_hit = int((d >= target).sum())
        print(f"{m:6s} | {len(d):4d} | {budget} | {d.max():.3f} | {d.min():.3f} | "
              f"{d.mean():.3f} | {d.std():.3f} | {n_hit}")
        summary_rows.append([m, len(d), budget, d.max(), d.min(), d.mean(), d.std(), n_hit])
    print("(best = largest, worst = smallest; std is the population std, ddof=0, as in Part 1)")

    with open("arm_summary.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["method", "runs", "budget", "best_m", "worst_m", "mean_m", "std_m", "runs_reaching_target"])
        w.writerows(summary_rows)

    for m, name in (("PSO", "arm_best_angles_pso.csv"), ("DE", "arm_best_angles_de.csv")):
        np.savetxt(name, best_vec[m][1], delimiter=",")
    winner = max(best_vec, key=lambda m: best_vec[m][0])
    np.savetxt("arm_best_angles.csv", best_vec[winner][1], delimiter=",")
    print(f"\nOverall winner: {winner} ({best_vec[winner][0]:.3f} m) -> arm_best_angles.csv")

    print("\nRe-simulating each winning vector (sign / reproducibility check):")
    for m in ("PSO", "DE"):
        dist, angles, seed = best_vec[m]
        again = arm.landing_distance(angles)
        status = "OK" if abs(again - dist) < 1e-4 else "MISMATCH -- investigate before trusting results"
        print(f"  {m} (seed {seed}): reported {dist:.6f} m, re-simulated {again:.6f} m -> {status}")

    print("\nReplay one at a time with the course script (drop --headless for the window).")
    print("Keep the quotes: in PowerShell an unquoted angle list gets altered and gives a wrong distance.")
    for m in ("PSO", "DE"):
        a = ",".join(repr(float(x)) for x in best_vec[m][1])
        print(f'  {m}: python replay.py "--angles={a}"')


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--target", type=float, default=8.0)
    args = ap.parse_args()
    arm.connect()
    summarize(args.target)
