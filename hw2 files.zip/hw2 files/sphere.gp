reset
# Part B: Sphere, n = 2
# f_sphere(x) = sum_{j=1}^{n} x_j^2   ->  for n = 2:  f(x1,x2) = x1^2 + x2^2
f(x,y) = x**2 + y**2

set terminal pngcairo size 900,700 font ",12"
set xrange [-5.12:5.12]
set yrange [-5.12:5.12]
set xlabel "x_1"
set ylabel "x_2"
set samples 100
set isosamples 100
set xtics 1
set ytics 1

# ---- Surface plot ----
set output "sphere_surface.png"
set title "Sphere function (n = 2): surface"
set zlabel "f(x_1, x_2)" rotate parallel
set hidden3d
set pm3d
set key off
splot f(x,y) with pm3d

# ---- Contour map (top view) ----
reset
set terminal pngcairo size 900,700 font ",12"
set output "sphere_contour.png"
set title "Sphere function (n = 2): contour map"
set xrange [-5.12:5.12]
set yrange [-5.12:5.12]
set xlabel "x_1"
set ylabel "x_2"
set xtics 1
set ytics 1
set samples 200
set isosamples 200
set key off
set view map
set contour base
set cntrparam levels 15
unset surface
set size ratio -1
splot f(x,y) with lines
