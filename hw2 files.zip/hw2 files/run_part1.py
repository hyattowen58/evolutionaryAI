"""Part C experiment: 30 seeds x {PSO, DE} x {sphere, Rastrigin}.

    python run_part1.py

Run test_optimizers.py first. Needs benchmarks.py, de.py, pso.py and
protocol.py in the same folder. Writes four CSV files (one value per seed).
"""
#some online help for file exports

import numpy as np

from benchmarks import sphere, rastrigin
from protocol import (N, n, lb, ub, T, W, C1, C2, F, CR, BUDGET, SEEDS,
                      BOUNDS_RULE, run_pso, run_de, quiet)


def run_30_seeds(algo, func, name):
    results = []
    for seed in SEEDS:
        fx, g, n_evals = quiet(algo, func, seed)
        assert n_evals == BUDGET, f"{name} seed {seed}: spent {n_evals}, expected {BUDGET}"
        results.append(fx)
    results = np.array(results)
    print(f"{name:14s} best={results.min():.6g}  worst={results.max():.6g}  "
          f"mean={results.mean():.6g}  std={results.std():.6g}")
    return results


if __name__ == "__main__":
    print(f"Protocol: n={n}, box=[{lb}, {ub}], N={N}, T={T}, budget={BUDGET}, "
          f"seeds={SEEDS.start}-{SEEDS.stop - 1}")
    print(f"PSO: w={W}, c1={C1}, c2={C2} | DE: F={F}, CR={CR} | bounds: {BOUNDS_RULE}\n")

    pso_sphere = run_30_seeds(run_pso, sphere, "PSO sphere")
    pso_rast = run_30_seeds(run_pso, rastrigin, "PSO rastrigin")
    de_sphere = run_30_seeds(run_de, sphere, "DE sphere")
    de_rast = run_30_seeds(run_de, rastrigin, "DE rastrigin")

    np.savetxt("pso_sphere_results.csv", pso_sphere, delimiter=",")
    np.savetxt("pso_rastrigin_results.csv", pso_rast, delimiter=",")
    np.savetxt("de_sphere_results.csv", de_sphere, delimiter=",")
    np.savetxt("de_rastrigin_results.csv", de_rast, delimiter=",")
    print("\nRaw per-run results saved (4 CSV files, one value per seed).")
