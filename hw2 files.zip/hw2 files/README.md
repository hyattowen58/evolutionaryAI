# HOMEWORK-02: PSO vs differential evolution

Owen Hyatt, Evolutionary AI, 10/13/2026.

## Requirements
- Python 3 with numpy (Part 1) and numpy + pybullet (Part 2). I used Python 3.13 and PyBullet 3.2.7.
- gnuplot (Part B).
- Run everything from this folder. Commands below use `python`; on my Windows machine
  I used the full path to the venv python.

## Files
Provided:
replay.py, arm-visualize.py, arm-viewer.py

## Part A: implementations and checks
python test_optimizers.py          # sphere check at 1530 evaluations, same seed gives same result
python test_de_requirements.py     # checks the four DE requirements

## Part B: figures (n = 2)
gnuplot sphere.gp                  # writes sphere_surface.png, sphere_contour.png
gnuplot rastrigin.gp               # writes rastrigin_surface.png, rastrigin_contour.png

## Part C: benchmark experiment (30 seeds, 1530 evaluations per run)
python run_part1.py                # prints the table, writes the 4 result CSVs

## Part F: budget search
python run_budget_search.py --gens 5 10 20 40 --runs 3 --target 8
(writes budget_search.csv, budget_search_config.json)

## Part G: arm competition (budget 1230, seeds 0-9)
python run_arm.py --gens 40 --methods PSO
python run_arm.py --gens 40 --methods DE
python summarize_arm.py            # table, best-angle files, re-simulation check

## Replaying the winning throws
python arm-visualize.py            # reads arm_best_angles.csv (the DE winner)
python replay.py "--angles=<seven angles>"

## Parameters and settings used
Part 1: n= 10, [-5.12, 5.12], population = 30, generations = 50, evaluations per run = 1530, seeds = 0-29
Part 2: n = 7, [-pi/2, pi/2], population = 30, generations = 40, evaluations per run = 1230, seeds = 0-9
w = 0.7, c1=c2=1.4
F = 0.5, CR = 0.9, r1, r2, r3 are distinct and random. 