"""Part A: check the four DE requirements the homework says will be checked.

    python test_de_requirements.py

How it works: np.random.default_rng is wrapped so every random draw de() makes is
recorded. The test then rebuilds what each trial vector must be from those draws and
the population as it stood at the start of the generation, and compares it with the
trial array de() actually sent to the objective function. If any requirement is broken,
the rebuilt trial differs and the test fails.

  1. r1, r2, r3 distinct from each other and from i   -> checked on every draw
  2. j_rand forced from the donor, so u_i != x_i       -> checked on every trial
  3. synchronous update (all trials from start-of-generation population)
                                                       -> rebuilt trials must match exactly
  4. one-to-one selection (trial i competes only with target i)
                                                       -> rebuilt population must match the
                                                          best value de() returns
"""
import numpy as np

import de as de_module
from benchmarks import sphere
from protocol import N, n, lb, ub, T, F, CR


class Recorder:
    """Wraps a numpy Generator; behaves identically but logs every draw."""
    def __init__(self, gen):
        self._gen = gen
        self.log = []                       # list of (method, args, result)

    def __getattr__(self, name):
        fn = getattr(self._gen, name)
        def wrapper(*args, **kwargs):
            out = fn(*args, **kwargs)
            self.log.append((name, args, out))
            return out
        return wrapper


def run_with_recording(seed):
    holder = {}
    real = np.random.default_rng

    def fake(s):
        holder["rec"] = Recorder(real(s))
        return holder["rec"]

    calls = []                              # every array passed to the objective

    def func(X):
        calls.append(np.array(X, copy=True))
        return sphere(X)

    np.random.default_rng = fake
    try:
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()):
            result = de_module.de(N, n, lb, ub, T, F, CR, func, seed)
    finally:
        np.random.default_rng = real
    return result, holder["rec"].log, calls


def check(seed):
    (fx_best, g_best, n_evals), log, calls = run_with_recording(seed)

    # draws after the initial-population draw, grouped per target i
    per_target = []
    k = 1                                   # log[0] is the initial population
    while k < len(log):
        (m1, a1, r) = log[k]
        (m2, a2, j_rand) = log[k + 1]
        (m3, a3, rnd) = log[k + 2]
        assert (m1, m2, m3) == ("choice", "integers", "random"), "unexpected draw order"
        per_target.append((np.asarray(r), int(j_rand), np.asarray(rnd)))
        k += 3
    assert len(per_target) == N * T, f"expected {N*T} trial constructions, saw {len(per_target)}"

    x = calls[0].copy()                     # initial population
    fx = sphere(x)
    n_checked = 0

    for g in range(T):
        trial_actual = calls[g + 1]
        trial_expected = np.empty_like(x)
        for i in range(N):
            r, j_rand, rnd = per_target[g * N + i]
            r1, r2, r3 = r

            
            assert len({int(r1), int(r2), int(r3), i}) == 4, \
                f"gen {g}, i={i}: r1,r2,r3,i not all distinct: {r1},{r2},{r3}"

            #donor built from x as it stood at the start of generation g
            v = x[r1] + F * (x[r2] - x[r3])
            cross = rnd < CR
            cross[j_rand] = True
            u = np.where(cross, v, x[i])
            trial_expected[i] = np.clip(u, lb, ub)

            #forced j_rand component comes from the donor, so u != x_i
            assert not np.array_equal(trial_actual[i], x[i]), \
                f"gen {g}, i={i}: trial equals its target"
            n_checked += 1

        assert np.array_equal(trial_actual, trial_expected), \
            f"gen {g}: trial array differs from a start-of-generation rebuild (not synchronous?)"

        #one-to-one selection, rebuilt independently
        fx_trial = sphere(trial_actual)
        better = fx_trial < fx
        x[better] = trial_actual[better]
        fx[better] = fx_trial[better]

    assert fx.min() == fx_best, "returned best does not match one-to-one selection rebuilt here"
    assert n_evals == N * (1 + T) == len(calls) * N
    return n_checked


if __name__ == "__main__":
    total = 0
    for seed in (0, 1, 2, 7, 29):
        total += check(seed)
        print(f"seed {seed}: OK")
    print(f"\nAll four DE requirements hold ({total} trial vectors rebuilt and checked).")
