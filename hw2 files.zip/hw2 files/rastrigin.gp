reset
# Part B: Rastrigin, n = 2
# f_rast(x) = 10 n + sum_{j=1}^{n} ( x_j^2 - 10 cos(2 pi x_j) )
# For n = 2 the constant 10n becomes 20, and there is one cosine term per variable:
#   f(x1,x2) = 20 + (x1^2 - 10 cos(2 pi x1)) + (x2^2 - 10 cos(2 pi x2))
f(x,y) = 20 + (x**2 - 10*cos(2*pi*x)) + (y**2 - 10*cos(2*pi*y))

set terminal pngcairo size 900,700 font ",12"
set xrange [-5.12:5.12]
set yrange [-5.12:5.12]
set xlabel "x_1"
set ylabel "x_2"
set xtics 1
set ytics 1

# Local minima are about 1 unit apart, so the grid must be much finer than 1
# unit. 200 points over a 10.24-wide box is ~0.05 per step.
set samples 200
set isosamples 200

# ---- Surface plot ----
set output "rastrigin_surface.png"
set title "Rastrigin function (n = 2): surface"
set zlabel "f(x_1, x_2)" rotate parallel
set hidden3d
set pm3d
set key off
splot f(x,y) with pm3d

# ---- Contour map (top view) ----
reset
set terminal pngcairo size 900,700 font ",12"
set output "rastrigin_contour.png"
set title "Rastrigin function (n = 2): contour map"
set xrange [-5.12:5.12]
set yrange [-5.12:5.12]
set xlabel "x_1"
set ylabel "x_2"
set xtics 1
set ytics 1
set samples 300
set isosamples 300
set key off
set view map
set contour base
set cntrparam levels 25
unset surface
set size ratio -1
splot f(x,y) with lines
unset output
