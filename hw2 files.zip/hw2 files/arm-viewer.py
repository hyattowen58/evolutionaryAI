import pybullet as p
import pybullet_data
import time
import warnings

# Connect PyBullet GUI
client_id = p.connect(p.GUI)
if client_id < 0:
    raise RuntimeError("Could not connect to the PyBullet GUI.")

try:
    # Set gravity and environment
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.81)
    plane = p.loadURDF("plane.urdf")

    # Load the KUKA IIWA robot arm
    robot_arm = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0])

    # Collect joint information and set up sliders
    joint_sliders = {}
    joint_targets = {}
    slider_failure_since = {}
    warned_about_slider_read = False
    num_joints = p.getNumJoints(robot_arm)

    for joint_id in range(num_joints):
        joint_info = p.getJointInfo(robot_arm, joint_id)
        joint_name = joint_info[1].decode('utf-8')
        joint_type = joint_info[2]

        # Only revolute or prismatic joints are controllable
        if joint_type in [p.JOINT_REVOLUTE, p.JOINT_PRISMATIC]:
            lower_limit, upper_limit = joint_info[8], joint_info[9]

            # Handle joints without proper limits
            if lower_limit >= upper_limit:
                lower_limit, upper_limit = -3.14, 3.14

            slider = p.addUserDebugParameter(
                paramName=joint_name,
                rangeMin=lower_limit,
                rangeMax=upper_limit,
                startValue=0
            )
            if slider < 0:
                raise RuntimeError(f"Could not create GUI slider for {joint_name}.")
            joint_sliders[joint_id] = slider
            joint_targets[joint_id] = 0.0

    # Closing the GUI ends the simulation.
    while p.isConnected(client_id):
        try:
            for joint_id, slider in joint_sliders.items():
                try:
                    joint_targets[joint_id] = p.readUserDebugParameter(
                        slider, physicsClientId=client_id
                    )
                    slider_failure_since.pop(joint_id, None)
                except p.error as exc:
                    if not p.isConnected(client_id):
                        break
                    # Reads can fail intermittently even for valid GUI sliders.
                    # Hold the last target and retry on the next simulation tick.
                    now = time.monotonic()
                    first_failure = slider_failure_since.setdefault(joint_id, now)
                    if now - first_failure >= 2.0:
                        raise RuntimeError(
                            f"GUI slider {slider} for joint {joint_id} has been "
                            "unreadable for two seconds."
                        ) from exc
                    if not warned_about_slider_read:
                        warnings.warn(
                            "PyBullet slider read failed; holding the last target "
                            "and retrying. Further transient warnings are suppressed.",
                            RuntimeWarning,
                        )
                        warned_about_slider_read = True
                p.setJointMotorControl2(
                    bodyUniqueId=robot_arm,
                    jointIndex=joint_id,
                    controlMode=p.POSITION_CONTROL,
                    targetPosition=joint_targets[joint_id],
                    force=200
                )
            if not p.isConnected(client_id):
                break
            p.stepSimulation()
        except p.error:
            # The window can close between the connection check and any API call.
            if p.isConnected(client_id):
                raise
            break
        time.sleep(1. / 240.)
except KeyboardInterrupt:
    pass
finally:
    if p.isConnected(client_id):
        p.disconnect(client_id)
