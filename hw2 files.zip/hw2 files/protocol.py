"""Shared Part C protocol settings and helpers, used by test_optimizers.py
and run_part1.py so the two can never disagree."""
import contextlib
import io

from de import de
from pso import pso

# ---------------------------------------------------------------------------
# Fixed protocol (Part C) -- do not change
# ---------------------------------------------------------------------------
N, n, lb, ub, T = 30, 10, -5.12, 5.12, 50      # population, dimension, box, generations
W, C1, C2 = 0.7, 1.4, 1.4                       # PSO parameters
F, CR = 0.5, 0.9                                # DE parameters
BUDGET = N * (1 + T)                            # 1530 evaluations per run
SEEDS = range(30)                               # seeds 0-29
BOUNDS_RULE = "clip to [-5.12, 5.12] (both methods)"


def run_pso(func, seed):
    return pso(N, n, lb, ub, T, W, C1, C2, func, seed=seed)


def run_de(func, seed):
    return de(N, n, lb, ub, T, F, CR, func, seed=seed)


def quiet(fn, *args, **kwargs):
    """Run fn with its per-generation prints suppressed."""
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*args, **kwargs)
