"""Part F: find the smallest evaluation budget at which at least one run of at
least one method lands the ball 8 m or farther.

    python run_budget_search.py                       # defaults
    python run_budget_search.py --gens 5 10 20 40 --runs 3 --target 8

Population stays at 30, so budget = 30 * (1 + G) and only G changes. Both
methods get every budget. Each budget's row is written to budget_search.csv
as soon as it finishes, so an interrupted search keeps what it has.
"""

#this script makes budget_search.csv and budget_search_config.json
#file includes some online help
import argparse
import csv
import json
import time

import arm # arm.py has the throw simulation and run_method()

N = arm.N #population size, 30


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gens", type=int, nargs="+", default=[5, 10, 20, 40, 80, 160, 320],
                    help="generation counts to try, in increasing order")
    ap.add_argument("--runs", type=int, default=3, help="seeds per method per budget (seeds 0..runs-1)")
    ap.add_argument("--target", type=float, default=8.0, help="distance in meters to reach")
    args = ap.parse_args()

    arm.connect() #starts pybullet
    #saves settings so the config file exists if run stops early
    with open("budget_search_config.json", "w") as fh:
        json.dump({"environment": arm.environment_config(),
                   "pso": {"w": arm.W, "c1": arm.C1, "c2": arm.C2},
                   "de": {"F": arm.F, "CR": arm.CR},
                   "population": N, "dimension": arm.n,
                   "bounds": [arm.LB, arm.UB], "bounds_rule": "clip (both methods)",
                   "seeds": list(range(args.runs)), "target_m": args.target}, fh, indent=2)

    rows, reached_at = [], None
    t_start = time.time()
    print(f"Target: {args.target} m | seeds 0-{args.runs - 1} | population {N}\n")
    for G in args.gens:
        budget = N * (1 + G) #i.e. 30 * (1 + G)
        best = {"PSO": -1e9, "DE": -1e9} # so any real distance beats it
        for method in ("PSO", "DE"):
            for seed in range(args.runs):
                t0 = time.time()
                dist, _ = arm.run_method(method, G, seed)
                best[method] = max(best[method], dist)
                print(f"  G={G:4d} budget={budget:6d} {method:3s} seed={seed}: "
                      f"{dist:8.3f} m  ({time.time() - t0:.0f} s)")
        overall = max(best.values())
        hit = overall >= args.target
        row = {"budget": budget, "generations": G, "runs": 2 * args.runs,
               "best_pso_m": round(best["PSO"], 6), "best_de_m": round(best["DE"], 6),
               "best_distance_m": round(overall, 6), "reached_target": "yes" if hit else "no"}
        rows.append(row)
        #rewrite the whole csv after every budget so a stopped run keeps its rows
        with open("budget_search.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(row))
            w.writeheader()
            w.writerows(rows)
        print(f"==> budget {budget} (G={G}): best {overall:.3f} m, reached {args.target} m? "
              f"{'YES' if hit else 'no'}\n")
        if hit:
            reached_at = budget
            break #stop if budget works

    print("budget tried | generations | runs | best distance seen | >= target?")
    for r in rows:
        print(f"{r['budget']:12d} | {r['generations']:11d} | {r['runs']:4d} | "
              f"{r['best_distance_m']:18.3f} | {r['reached_target']}")
    if reached_at:
        print(f"\nSmallest budget tried that reached {args.target} m: {reached_at}")
        #only the budgets on my list were tested, so 1230 is not a proven minimum
        print("(smallest on the grid you tried and with these seeds; refine with --gens if you want it tighter)")
    else:
        print(f"\nDid NOT reach {args.target} m. Largest budget run: {rows[-1]['budget']}, "
              f"best distance seen: {max(r['best_distance_m'] for r in rows):.3f} m")
    print(f"Total time: {(time.time() - t_start) / 60:.1f} min")


if __name__ == "__main__":
    main()
