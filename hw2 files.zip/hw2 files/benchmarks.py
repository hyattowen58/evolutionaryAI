import numpy as np


def sphere(x):
    """Benchmark: minimum is 0 at the origin. x has shape (N, n)."""
    return np.sum(x * x, axis=1)


def rastrigin(x):
    n = x.shape[1]
    return 10 * n + np.sum(x**2 - 10 * np.cos(2 * np.pi * x), axis=1)
