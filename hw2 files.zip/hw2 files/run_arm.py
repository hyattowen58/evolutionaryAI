"""Part G: the arm competition -- PSO against DE on the same seeds and budget.

    python run_arm.py --gens 40                        # both methods, 10 runs each, seeds 0-9
    python run_arm.py --gens 40 --runs 10 --target 8

To use two PowerShell windows at once (each run is single-threaded), run one
method per window, then summarize:

    python run_arm.py --gens 40 --methods PSO          # window 1
    python run_arm.py --gens 40 --methods DE           # window 2
    python summarize_arm.py                            # after both finish

Budget = 30 * (1 + G) evaluations per run, identical for both methods.

Writes (in the current folder):
  arm_runs_<METHOD>.csv      raw result of every run (seed, distance, 7 angles),
                             written as each run finishes, so an interrupted
                             session keeps what it has
  arm_config_<METHODS>.json  environment + parameters + seeds + budget
and, once both methods are present (see summarize_arm.py):
  arm_summary.csv, arm_best_angles_pso.csv, arm_best_angles_de.csv, arm_best_angles.csv
"""
import argparse
import csv
import json
import time

import arm
import summarize_arm

N = arm.N


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gens", type=int, required=True, help="generations G (budget = 30*(1+G))")
    ap.add_argument("--runs", type=int, default=10, help="runs per method, seeds 0..runs-1")
    ap.add_argument("--target", type=float, default=8.0)
    ap.add_argument("--methods", nargs="+", choices=["PSO", "DE"], default=["PSO", "DE"],
                    help="which methods to run in this window (default: both)")
    args = ap.parse_args()

    methods = list(dict.fromkeys(args.methods))
    budget = N * (1 + args.gens)
    seeds = list(range(args.runs))
    arm.connect()
    config = {"environment": arm.environment_config(),
              "methods_in_this_invocation": methods,
              "pso": {"w": arm.W, "c1": arm.C1, "c2": arm.C2},
              "de": {"F": arm.F, "CR": arm.CR},
              "population": N, "dimension": arm.n, "generations": args.gens,
              "budget_evaluations": budget, "bounds": [arm.LB, arm.UB],
              "bounds_rule": "clip (both methods)", "seeds": seeds,
              "objective": "maximize landing distance; optimizers minimize -distance"}
    with open("arm_config_" + "_".join(methods) + ".json", "w") as fh:
        json.dump(config, fh, indent=2)

    print(f"Budget {budget} evaluations per run (G={args.gens}) | methods {methods} | "
          f"seeds {seeds[0]}-{seeds[-1]}\n", flush=True)

    files = {m: open(f"arm_runs_{m}.csv", "w", newline="") for m in methods}
    writers = {m: csv.writer(files[m]) for m in methods}
    for m in methods:
        writers[m].writerow(["method", "seed", "distance_m"] + [f"angle{j + 1}" for j in range(arm.n)])
        files[m].flush()

    t_start = time.time()
    try:
        for seed in seeds:
            for m in methods:
                t0 = time.time()
                dist, angles = arm.run_method(m, args.gens, seed)
                writers[m].writerow([m, seed, repr(dist)] + [repr(float(a)) for a in angles])
                files[m].flush()
                print(f"seed {seed} {m:3s}: {dist:8.3f} m  ({time.time() - t0:.0f} s, "
                      f"{(time.time() - t_start) / 60:.1f} min elapsed)", flush=True)
    finally:
        for fh in files.values():
            fh.close()

    if set(methods) == {"PSO", "DE"}:
        summarize_arm.summarize(args.target)
    else:
        other = "DE" if methods == ["PSO"] else "PSO"
        print(f"\nDone with {methods[0]}. Run the other method with --methods {other} "
              f"(same --gens and --runs), then: python summarize_arm.py")
    print(f"\nTotal time: {(time.time() - t_start) / 60:.1f} min")


if __name__ == "__main__":
    main()
