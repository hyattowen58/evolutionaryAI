"""KUKA-arm throw for Part 2, plus the glue that hands it to PSO and DE.

Same motion and release timing as replay.py / arm-visualize.py: the optimizer
picks the 7 STARTING joint angles; every joint is then commanded toward
(start + 0.2 rad) for 1 s with the ball attached; the ball is released and
flies for 2 s; the score is the ball's final world x in meters.

SIGN CONVENTION (Part H, question 3): the arm objective is MAXIMIZED (farther is
better) but pso() and de() MINIMIZE. The sign is flipped in exactly one place,
arm_cost() below, and flipped back in exactly one place, run_method(). Nowhere
else.
"""
import math
import sys
from importlib import metadata
from pathlib import Path

import numpy as np
import pybullet as p
import pybullet_data

# Make the Part 1 optimizers importable whether the folders are side by side
# (part1/, part2/) or everything sits in one folder.
_HERE = Path(__file__).resolve().parent
for _d in (_HERE.parent / "part1", _HERE):
    sys.path.insert(0, str(_d))

from de import de          # noqa: E402  (unmodified Part 1 optimizers)
from pso import pso        # noqa: E402
from protocol import W, C1, C2, F, CR, quiet   # noqa: E402  (same parameters as Part 1)

# ---------------------------------------------------------------------------
# Simulation constants (identical to replay.py)
# ---------------------------------------------------------------------------
TIME_STEP = 1.0 / 240
SIM_STEPS = 240 * 3                 # 3-second throw
SWING_STEPS = SIM_STEPS // 3        # 1 s: arm moves, ball still attached
FLIGHT_STEPS = SIM_STEPS * 2 // 3   # 2 s: ball released
SWING_DELTA = 0.2                   # rad added to each starting angle as motor target
MOTOR_FORCE = 500

# ---------------------------------------------------------------------------
# Search settings for the arm
# ---------------------------------------------------------------------------
N = 30                               # population / swarm size (fixed by the homework)
n = 7                                # seven joint angles
LB, UB = -math.pi / 2, math.pi / 2   # same box for every joint

throw_count = 0   # independent count of simulated throws (checked against the budget)


def reset_throw_count():
    global throw_count
    throw_count = 0


def connect():
    client = p.connect(p.DIRECT)
    if client < 0:
        raise RuntimeError("Could not connect to PyBullet")
    return client


def landing_distance(joint_angles):
    """One simulated throw. Returns the ball's final world x in meters."""
    global throw_count
    throw_count += 1
    joint_angles = [float(a) for a in joint_angles]

    p.resetSimulation()
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.81)
    p.setTimeStep(TIME_STEP)
    p.setRealTimeSimulation(0)
    p.loadURDF("plane.urdf")
    robot = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0], useFixedBase=True)
    ball = p.loadURDF("sphere2.urdf", [0, 0, 0], globalScaling=0.05)

    for joint, angle in enumerate(joint_angles):
        p.resetJointState(robot, joint, angle)

    attachment = p.createConstraint(
        robot, p.getNumJoints(robot) - 1, ball, -1,
        p.JOINT_FIXED, [0, 0, 0], [0, 0, 0], [0, 0, 0])

    for _ in range(SWING_STEPS):
        for joint, angle in enumerate(joint_angles):
            p.setJointMotorControl2(robot, joint, p.POSITION_CONTROL,
                                    targetPosition=angle + SWING_DELTA,
                                    force=MOTOR_FORCE)
        p.stepSimulation()

    p.removeConstraint(attachment)
    for _ in range(FLIGHT_STEPS):
        p.stepSimulation()

    position, _ = p.getBasePositionAndOrientation(ball)
    return float(position[0])


def arm_cost(X):
    """What the optimizers minimize: NEGATIVE landing distance (sign flip #1)."""
    return -np.array([landing_distance(a) for a in np.asarray(X).tolist()])


def run_method(method, G, seed):
    """One optimizer run on the arm. Returns (landing distance in m, 7 angles).

    Asserts the budget two ways: the optimizer's own count and an independent
    count of simulated throws, both equal to N * (1 + G).
    """
    budget = N * (1 + G)
    reset_throw_count()
    if method == "PSO":
        fx, g, n_evals = quiet(pso, N, n, LB, UB, G, W, C1, C2, arm_cost, seed=seed)
    elif method == "DE":
        fx, g, n_evals = quiet(de, N, n, LB, UB, G, F, CR, arm_cost, seed=seed)
    else:
        raise ValueError(method)
    assert n_evals == budget, f"{method}: optimizer counted {n_evals}, expected {budget}"
    assert throw_count == budget, f"{method}: simulated {throw_count} throws, expected {budget}"
    return float(-fx), g   # sign flip #2: cost back to a distance in meters


def environment_config():
    """Environment details the homework wants recorded with Part 2 results."""
    try:
        version = metadata.version("pybullet")
    except Exception:
        version = "unknown"
    p.resetSimulation()
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    robot = p.loadURDF("kuka_iiwa/model.urdf", [0, 0, 0], useFixedBase=True)
    return {
        "pybullet_version": version,
        "time_step_s": TIME_STEP,
        "sim_steps_total": SIM_STEPS,
        "swing_steps (ball attached)": SWING_STEPS,
        "flight_steps (ball released)": FLIGHT_STEPS,
        "motor_target": f"start angle + {SWING_DELTA} rad",
        "motor_force": MOTOR_FORCE,
        "gravity": [0, 0, -9.81],
        "urdf_arm": "kuka_iiwa/model.urdf (fixed base)",
        "urdf_ball": "sphere2.urdf, globalScaling=0.05",
        "urdf_floor": "plane.urdf",
        "arm_num_joints_reported_by_pybullet": p.getNumJoints(robot),
        "score": "ball final world x (m), maximized",
    }
